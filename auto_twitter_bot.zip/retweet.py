import tweepy
import os

def auto_retweet(client):
    keyword = os.getenv("RETWEET_KEYWORD", "promo").lower()

    tweets = client.search_recent_tweets(query=keyword, max_results=5)

    if tweets.data:
        for tweet in tweets.data:
            try:
                client.retweet(tweet.id)
                print(f"Retweeted: {tweet.id}")
            except Exception as e:
                print("Retweet error:", e)
