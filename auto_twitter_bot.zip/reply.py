import tweepy
import os
import random

def auto_reply(client):
    query = os.getenv("REPLY_KEYWORD", "giveaway").lower()
    messages = [
        "Mantap banget! 🔥",
        "Setuju nih! 😎",
        "Keren! 🙌",
        "Thanks infonya! 👍"
    ]

    tweets = client.search_recent_tweets(query=query, max_results=5)

    if tweets.data:
        for tweet in tweets.data:
            try:
                msg = random.choice(messages)
                client.create_tweet(
                    in_reply_to_tweet_id=tweet.id,
                    text=f"{msg}"
                )
                print(f"Replied to: {tweet.id}")
            except Exception as e:
                print("Reply error:", e)
