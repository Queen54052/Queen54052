import os
import tweepy
from reply import auto_reply
from retweet import auto_retweet
from dm import auto_dm

def twitter_api():
    client = tweepy.Client(
        consumer_key=os.getenv("API_KEY"),
        consumer_secret=os.getenv("API_SECRET"),
        access_token=os.getenv("ACCESS_TOKEN"),
        access_token_secret=os.getenv("ACCESS_SECRET"),
        wait_on_rate_limit=True
    )
    return client

def main():
    client = twitter_api()

    print("Running Auto Reply...")
    auto_reply(client)

    print("Running Auto Retweet...")
    auto_retweet(client)

    print("Running Auto DM...")
    auto_dm(client)

if __name__ == "__main__":
    main()
