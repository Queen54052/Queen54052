import tweepy
import os

def auto_dm(client):
    message = os.getenv("DM_MESSAGE", "Halo! Thanks sudah follow 😎")

    followers = client.get_users_followers(id=os.getenv("BOT_USER_ID"))
    sent_file = "sent_dm.txt"

    if not os.path.exists(sent_file):
        open(sent_file, "w").close()

    with open(sent_file, "r") as f:
        sent_list = f.read().splitlines()

    for follower in followers.data:
        if follower.id not in sent_list:
            try:
                client.send_direct_message(
                    recipient_id=follower.id,
                    text=message
                )
                print(f"DM sent to: {follower.username}")

                with open(sent_file, "a") as f:
                    f.write(f"{follower.id}\n")

            except Exception as e:
                print("DM error:", e)
